import 'package:dio/dio.dart';

class YTClient {
  Dio dio = Dio();

  getytDataFromAPI() async {
    String ytURL =
        "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&maxResults=200&regionCode=IN&key=%20AIzaSyCr0s2hzyYXvPjrs6LO5pXA0J3IYPcuyAg";
    try {
      var response = await dio.get(ytURL);
      print("this is the youtube data from the API ${response.data}");
      return response.data;
    } catch (error) {
      print("Error in fetchind data from API");
    }
  }
}
//[0]['items'][0]['snippet'][0]['thumbnails'][0] ['default'][0]['url']