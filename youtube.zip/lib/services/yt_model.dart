class YTModel {
  late Source snippet;
  late String title;
  late String description;
  late String thumbnails;
  late String url;
  late String channelTitle;
  late String src;

  YTModel({
    required this.title,
    required this.description,
    required this.thumbnails,
    required this.url,
    required this.channelTitle,
    required this.src,
  });

  YTModel.extractFromJSON(Map<String, dynamic> map) {
    snippet = Source.extractSourceFromJSON(map['snippet']);
    title = map['snippet']['title'] ?? "not available";
    description = map['snippet']['description'] ?? "not available";
    thumbnails =
        map['snippet']['thumbnails']['standard']['url'] ?? "Not available";
    channelTitle = map['snippet']['channelTitle'] ?? "not available";
    src = map['snippet']['player'] ?? "not available";
    url = map['url'] ?? "not available";
  }
}

class Source {
  late String channelId;
  late String publishedAt;
  Source({required this.channelId, required this.publishedAt});
  Source.extractSourceFromJSON(Map<String, dynamic> map) {
    channelId = map['channelId'] ?? "not available";
    publishedAt = map['publishedAt'] ?? "not available";
  }
}
