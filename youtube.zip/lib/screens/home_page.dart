import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:yt_clone/services/yt_client.dart';

import '../services/yt_model.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

YTClient ytClient = YTClient();

Future<List<YTModel>> getYT() async {
  Map<String, dynamic> ytMap = await ytClient.getytDataFromAPI();
  List<dynamic> ytList = ytMap['items'];
  List<YTModel> youtubeList = genericToSpecificObject(ytList);
  return youtubeList;
}

genericToSpecificObject(List<dynamic> list) {
  List<YTModel> ytList = list.map((singleObject) {
    YTModel singleYT = YTModel.extractFromJSON(singleObject);
    return singleYT;
  }).toList();

  return ytList;
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.white,
              title: Row(
                children: [
                  Image.asset(
                    'assets/yt.png', // Replace with your logo image path
                    width: 40,
                    height: 40,
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'YouTube',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
              actions: [
                IconButton(
                  icon: const Icon(
                    Icons.cast,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    // Handle cast action
                  },
                ),
                IconButton(
                  icon: const Icon(
                    Icons.search,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    // Handle search action
                  },
                ),
                IconButton(
                  icon: const Icon(
                    Icons.account_circle,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    // Handle account action
                  },
                ),
              ],
            ),
            body: Container(
                color: Colors.transparent,
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                child: FutureBuilder(
                  future: getYT(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    } else if (snapshot.hasError) {
                      return Center(
                        child: Text(snapshot.error.toString()),
                      );
                    } else if (snapshot.hasData) {
                      return ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.8,
                              child: Card(
                                color: Colors.white60,
                                child: Column(
                                  children: [
                                    Image.network(
                                        snapshot.data![index].thumbnails),
                                    // VideoPlayer(snapshot.data![index].src
                                    //     as VideoPlayerController),
                                    Text(
                                      snapshot.data![index].title,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20),
                                    ),
                                    Text(
                                      snapshot.data![index].channelTitle,
                                      style: const TextStyle(
                                          color: Colors.black54,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15),
                                    ),

                                    // Text(
                                    //   snapshot.data![index].description,
                                    //   style: const TextStyle(
                                    //       color: Colors.blue,
                                    //       fontWeight: FontWeight.bold,
                                    //       fontSize: 10),
                                    // ),
                                  ],
                                ),
                              ),
                            );
                          });
                    }
                    return Container();
                  },
                ))));
  }
}
