import 'package:dict/screens/homePage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: HOME(),
  ));
}
