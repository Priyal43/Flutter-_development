import 'package:dict/service/dictClient.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HOME extends StatefulWidget {
  const HOME({super.key});

  @override
  State<HOME> createState() => _HOMEState();
}

class _HOMEState extends State<HOME> {
  DictClient dClient = DictClient();
  TextEditingController tc = TextEditingController();
  String meaning = "null";
  //  @override
  // void initState() {
  //   print("i was called first");
  //   TODO: implement initState//
  //   super.initState();
  // }
  callAPI(q) async {
    dClient.searchForWord(query: q);
    //print("The API is called with the following word $q");
    meaning = await dClient.searchForWord(query: q);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text("DICTIONARY"),
          centerTitle: true,
        ),
        drawer: Drawer(
            child: DrawerHeader(
          child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.1,
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const DrawerHeader(
                    decoration: BoxDecoration(color: Colors.pink),
                    child: Text("Drawer header"),
                  ),
                  ListTile(
                    leading: const Icon(Icons.home),
                    tileColor: Colors.pink[50],
                    title: const Text("Home"),
                    onTap: () {
                      print("Home is tapped");
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                      leading: const Icon(Icons.account_box),
                      tileColor: Colors.pink[100],
                      title: const Text("Account")),
                  ListTile(
                      leading: const Icon(Icons.shop_2),
                      tileColor: Colors.pink[200],
                      title: const Text("Cart")),
                  ListTile(
                      leading: const Icon(Icons.help),
                      tileColor: Colors.pink[300],
                      title: const Text("Help")),
                  ListTile(
                      leading: const Icon(Icons.logout),
                      tileColor: Colors.pink[400],
                      title: const Text("logout"))
                ],
              )),
        )),
        body: SizedBox(
          //color: Colors.white,
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: tc,
                  decoration: InputDecoration(
                      border: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(50))),
                      suffixIcon: IconButton(
                          onPressed: () {}, icon: const Icon(Icons.clear)),
                      label: const Text("Search"),
                      hintText: "Type here..."),
                  // style: ,
                  keyboardType: TextInputType.number,
                  onChanged: (string) {
                    // print(textfield.text); //controller--> text
                    print("This is the text from the textfield $string");
                  },
                  onEditingComplete: () {
                    // print(
                    //     // "this is the final submission from the textfield ${txtfld.text}");
                  },
                ),
              ),
              OutlinedButton(
                  onPressed: () {
                    callAPI(tc.text);
                  },
                  child: const Text("SEARCH")),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  color: Colors.purple[200],
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.2,
                  child: Text(
                    meaning,
                    style: GoogleFonts.armata(fontSize: 15),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
