import 'package:flutter/material.dart';
import 'package:news_app1/screens/home_page.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}
