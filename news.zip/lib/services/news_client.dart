import 'package:dio/dio.dart';

class NewsClient {
  Dio dio = Dio();

  getNewsDataFromAPI() async {
    String newsURL =
        "https://newsapi.org/v2/top-headlines?country=in&apiKey=78f9e23b17d44e85b34e584083334b6b";
    try {
      var response = await dio.get(newsURL);
      print("this is the news data from the API ${response.data}");
      return response.data;
    } catch (error) {
      print("Error in fetchind data from API");
    }
  }
}
