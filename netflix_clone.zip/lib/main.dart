import 'package:flutter/material.dart';
// import 'package:nf_clone/screen/homePage.dart';
import 'package:nf_clone/navbar.dart';

void main() {
  runApp(const MaterialApp(
    home: NavBar(),
    // home: HomePage(),
  ));
}
