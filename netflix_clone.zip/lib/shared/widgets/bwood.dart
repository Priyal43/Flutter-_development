import 'package:flutter/material.dart';

class BWOOD extends StatelessWidget {
  const BWOOD({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text("Indian movies",
          style: TextStyle(
              color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
      SizedBox(
          width: double.infinity,
          height: 200,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/bollywood (1).jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/bollywood (2).jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/bollywood (3).jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/bollywood (4).jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/bollywood6.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/bollywood7.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/bollywood9.jpg"),
            ),
          ]))
    ]);
  }
}
