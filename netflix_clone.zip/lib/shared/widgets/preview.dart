import 'package:flutter/material.dart';

class PREVIEW extends StatelessWidget {
  const PREVIEW({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Previews",
            style: TextStyle(
                color: Colors.white,
                fontSize: 25,
                fontWeight: FontWeight.bold)),
        SizedBox(
            width: double.infinity,
            height: 150,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("assets/stranger_things.jpg"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("umbrella_academy.jpg"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("assets/violet_evergarden.jpg"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("assets/witcher.jpg"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("assets/stranger_things.jpg"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("umbrella_academy.jpg"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("assets/violet_evergarden.jpg"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage("assets/witcher.jpg"),
                  ),
                ),
              ],
            ))
      ],
    );
  }
}
