import 'package:flutter/material.dart';

class MYLIST extends StatelessWidget {
  const MYLIST({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text("My list",
          style: TextStyle(
              color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
      SizedBox(
          width: double.infinity,
          height: 200,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/witcher.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/umbrella_academy.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/violet_evergarden.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/thirteen_reasons.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/witcher.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/umbrella_academy.jpg"),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Image.asset("assets/violet_evergarden.jpg"),
            ),
          ]))
    ]);
  }
}
