// import 'package:flutter/widgets.dart';

// class appConstant{
//   BuildContext context;
//   AppConstant({required this.context})
// }