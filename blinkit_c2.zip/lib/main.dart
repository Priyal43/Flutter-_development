//import 'package:blinkit_clone/screens/authScreen.dart';
import 'package:blinkit_clone/screens/homeScreen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: HomePage(),
  ));
}
