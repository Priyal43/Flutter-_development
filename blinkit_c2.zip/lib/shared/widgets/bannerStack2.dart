import 'package:flutter/material.dart';

class BannerStack2 extends StatefulWidget {
  final String imageAssetPath;
  const BannerStack2({super.key, required this.imageAssetPath});

  @override
  State<BannerStack2> createState() => _BannerStack2State();
}

class _BannerStack2State extends State<BannerStack2> {
  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
            height: MediaQuery.of(context).size.height * 0.3,
            width: MediaQuery.of(context).size.width * 0.4,
            color: Colors.black,
            child: Image.asset(
              widget.imageAssetPath,
              fit: BoxFit.cover,
            )),
      )
    ]);
  }
}
