import 'package:flutter/material.dart';

class BannerStack extends StatefulWidget {
  final String imageAssetPath;
  const BannerStack({super.key, required this.imageAssetPath});

  @override
  State<BannerStack> createState() => _BannerStackState();
}

class _BannerStackState extends State<BannerStack> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
            height: MediaQuery.of(context).size.height * 0.3,
            width: MediaQuery.of(context).size.width * 0.8,
            color: Colors.blue,
            child: Image.asset(
              widget.imageAssetPath,
              fit: BoxFit.cover,
            )),
        const Positioned(
          top: 15,
          left: 10,
          child: Text(
            "Buy 2 get 1 free!!!",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        const Positioned(
          top: 40,
          left: 10,
          child: Text(
            "Terms & Conditions applied",
            style: TextStyle(fontSize: 10),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 10,
            child: TextButton(
              onPressed: () {},
              child: const Text(
                "SHOP NOW",
                style: TextStyle(color: Colors.black),
              ),
            )),
      ],
    );
  }
}
