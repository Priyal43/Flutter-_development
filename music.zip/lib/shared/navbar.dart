import 'package:flutter/material.dart';
import 'package:music_app1/screens/Account.dart';
import 'package:music_app1/screens/alexa.dart';
import 'package:music_app1/screens/homePage.dart';
//import 'package:music_app1/shared/widgets/stack.dart';
import 'package:music_app1/screens/homeScreen.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int currentIndexs = 0;
  final List screens = [
    const HomePage(),
    HOME(),
    const ACCOUNT(),
    const Alexa()
    // const SongStack(),

    // const Search(),
    // const SETTINGS(),
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: screens[currentIndexs],
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: currentIndexs,
            type: BottomNavigationBarType.fixed,
            onTap: (value) {
              setState(() {
                currentIndexs = value;
              });
            },
            backgroundColor: Colors.black,
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white.withOpacity(.60),
            // selectedFontSize: 13,
            // unselectedFontSize: 10,
            items: const [
              BottomNavigationBarItem(label: "", icon: Icon(Icons.home)),
              BottomNavigationBarItem(label: "", icon: Icon(Icons.search)),
              BottomNavigationBarItem(label: "", icon: Icon(Icons.person)),
              BottomNavigationBarItem(
                  label: "", icon: Icon(Icons.circle_outlined)),
            ]),
      ),
    );
  }
}
