import 'package:flutter/material.dart';

class SongStack extends StatefulWidget {
  final String imageAssetPath;
  const SongStack({super.key, required this.imageAssetPath});

  @override
  State<SongStack> createState() => _SongStackState();
}

class _SongStackState extends State<SongStack> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.2,
            width: MediaQuery.of(context).size.width * 0.4,
            color: Colors.purple,
            child: Image.asset(widget.imageAssetPath),
          ),
          Positioned(
            bottom: 0,
            child: Container(
              height: MediaQuery.of(context).size.height * 0.1,
              width: MediaQuery.of(context).size.width * 0.4,
              color: Colors.purple[200],
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "50 most played",
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
