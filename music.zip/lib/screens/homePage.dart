import 'package:flutter/material.dart';
import 'package:music_app1/shared/widgets/stack.dart';

// ignore: must_be_immutable
class HOME extends StatefulWidget {
  HOME({super.key});

  @override
  State<HOME> createState() => _HOMEState();
  List<String> songImages = [
    'assets/s1.png',
    'assets/s2.png',
    'assets/s3.png',
    'assets/s4.png',
    'assets/s5.png',
    'assets/s6.png',
    'assets/s7.png',
    'assets/s8.png',
    'assets/s9.png',
    'assets/s10.png',
    'assets/s11.png',
    'assets/s12.png',
    'assets/s13.png',
    'assets/s14.png',
    'assets/s15.png',
    'assets/s16.png',
  ];

  List<Widget> getSongStacks() {
    return songImages.map((imagePath) {
      return SongStack(imageAssetPath: imagePath);
    }).toList();
  }
}

class _HOMEState extends State<HOME> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.black87,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: const Icon(Icons.notifications),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Chip(label: Text("MUSIC")),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.1,
            ),
            const Chip(label: Text("PODCAST"))
          ],
        ),
        centerTitle: true,
        actions: const [Icon(Icons.settings)],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Trending Playlists",
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
                Spacer(),
                Chip(label: Text("SEE MORE"))
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                  height: MediaQuery.of(context).size.height * 0.25,
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: const [
                      SongStack(
                        imageAssetPath: 'assets/s1.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s2.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s3.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s4.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s5.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s6.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s1.png',
                      ),
                    ],
                  )),
            ),
            const SizedBox(
              height: 20,
            ),
            const Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Start a Podcast Habit",
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
                Spacer(),
                Chip(label: Text("SEE MORE"))
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                  height: MediaQuery.of(context).size.height * 0.25,
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: const [
                      SongStack(
                        imageAssetPath: 'assets/s7.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s8.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s9.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s10.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s11.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s12.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s13.png',
                      ),
                    ],
                  )),
            ),
            const SizedBox(
              height: 20,
            ),
            const Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Shades of Love",
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
                Spacer(),
                Chip(label: Text("SEE MORE"))
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                  height: MediaQuery.of(context).size.height * 0.25,
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: const [
                      SongStack(
                        imageAssetPath: 'assets/s14.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s15.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s16.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s1.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s2.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s3.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s4.png',
                      ),
                    ],
                  )),
            ),
            const SizedBox(
              height: 20,
            ),
            const Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "R&B",
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
                Spacer(),
                Chip(label: Text("SEE MORE"))
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                  height: MediaQuery.of(context).size.height * 0.25,
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: const [
                      SongStack(
                        imageAssetPath: 'assets/s5.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s6.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s7.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s8.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s9.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s10.png',
                      ),
                      SongStack(
                        imageAssetPath: 'assets/s11.png',
                      ),
                    ],
                  )),
            ),
          ],
        ),
      ),
    ));
  }
}
