import 'package:flutter/material.dart';

class ACCOUNT extends StatefulWidget {
  const ACCOUNT({super.key});

  @override
  State<ACCOUNT> createState() => _ACCOUNTState();
}

class _ACCOUNTState extends State<ACCOUNT> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: const Icon(Icons.notifications),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Chip(label: Text("MUSIC")),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.1,
              ),
              const Chip(label: Text("PODCASTS")),
            ],
          ),
          centerTitle: true,
          actions: const [Icon(Icons.settings)],
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 70,
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                color: Colors.grey,
                child: const Row(
                  children: [
                    Text(
                      'Playlist',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                color: Colors.grey, // Set the background color
                child: const Row(
                  children: [
                    Text(
                      'Album',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                color: Colors.grey, // Set the background color
                child: const Row(
                  children: [
                    Text(
                      'Songs',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: const Row(
                  children: [
                    Text(
                      'Recents',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Image.asset(
                      'assets/Glimpse of Us.png',
                      width: 70,
                      height: 70,
                    ),
                    const SizedBox(width: 16),
                    const Text(
                      'Glimpse of Us',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Image.asset(
                      'assets/Chase Atlantic.png',
                      width: 70,
                      height: 70,
                    ),
                    SizedBox(width: 16),
                    const Text(
                      'SLIDE',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Image.asset(
                      'assets/Arctic Monkeys.png',
                      width: 70,
                      height: 70,
                    ),
                    SizedBox(width: 16),
                    const Text(
                      'I Wanna Be Yours',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Image.asset(
                      'assets/double take.png',
                      width: 70,
                      height: 70,
                    ),
                    SizedBox(width: 16),
                    const Text(
                      'double take',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Image.asset(
                      'assets/The Neighbourhood.png',
                      width: 70,
                      height: 70,
                    ),
                    SizedBox(width: 16),
                    const Text(
                      'Reflections',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios)
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
