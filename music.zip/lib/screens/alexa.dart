import 'package:flutter/material.dart';

class Alexa extends StatefulWidget {
  const Alexa({super.key});

  @override
  State<Alexa> createState() => _AlexaState();
}

class _AlexaState extends State<Alexa> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.black,
      body: Column(children: [
        const Padding(
          padding: EdgeInsets.all(40.0),
          child: Text(
            "Control music with your voice-",
            style: TextStyle(
                color: Colors.white, fontSize: 37, fontWeight: FontWeight.bold),
          ),
        ),
        const Text(
          "just ask Alexa",
          style: TextStyle(
              color: Colors.blue, fontSize: 35, fontWeight: FontWeight.bold),
        ),
        Image.asset(
          'assets/alexa_page.png',
          height: 200,
          width: 200,
        ),
        const SizedBox(
          height: 10,
        ),
        const Padding(
          padding: EdgeInsets.all(20.0),
          child: Text(
            "To use Alexa hands-free please allow access to your device's microphone",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(
          height: 100,
        ),
        const Chip(
          label: Text("Go to settings"),
        ),
        const Text("Cancle")
      ]),
    ));
  }
}
