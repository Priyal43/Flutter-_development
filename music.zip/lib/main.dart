import 'package:flutter/material.dart';
import 'package:music_app1/screens/homePage.dart';
import 'package:music_app1/screens/homeScreen.dart';
import 'package:music_app1/screens/loadingScreen.dart';
import 'package:music_app1/shared/navbar.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: const NavBar(),
    // home: const LoadingScreen(),
    theme: ThemeData.dark(),
    // initialRoute: '/',
    // routes: {
    //   '/': (context) => const LoadingScreen(),
    //   '/home': (context) => const HomePage(),
    //   '/home2': (context) => const HOME(),
    // },
  ));
}
