import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LOGIN extends StatefulWidget {
  const LOGIN({super.key});

  @override
  State<LOGIN> createState() => _LOGINState();
}

class _LOGINState extends State<LOGIN> {
  TextEditingController txtfld = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Column(
      children: [
        SizedBox(
          child: TextField(
              controller: txtfld,
              obscureText: true,
              decoration: InputDecoration(
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(50)),
                  ),
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(
                      onPressed: () {}, icon: const Icon(Icons.clear)),
                  label: const Text("Username"),
                  hintText: "min 8 characters"),
              obscuringCharacter: "*",
              keyboardType: TextInputType.number,
              onChanged: (string) {
                // print(controller.text);
                print("this is the text from textfield $string");
              }),
        ),
        Text("Hello Flutter", style: GoogleFonts.baiJamjuree(fontSize: 50)),
        // const Text("hello flutter", style: TextStyle(fontSize: 40)),
        // SizedBox(
        //   height: 200,
        //   width: 200,
        //   // decoration: const BoxDecoration(
        //   //     gradient: LinearGradient(
        //   //         colors: [Colors.white, Colors.purple, Colors.black])),
        //   child: Card(
        //     elevation: 20,
        //     color: Colors.purple.shade200,
        //     shadowColor: Colors.white,
        //   ),
        // )
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Chip(
              label: Text("Priyal❤️"),
              avatar: CircleAvatar(
                child: Text("😶‍🌫️"),
              ),

              // padding: EdgeInsets.all(20),
              // labelPadding: EdgeInsets.all(10),
              // deleteIcon: Icon(Icons.delete),
              // deleteIconColor: Colors.white,
            ),
            Chip(
              label: Text("Garvita❤️"),
              avatar: CircleAvatar(
                child: Text("😊"),
              ),
            ),
            Chip(
              label: Text("shiva❤️"),
              avatar: CircleAvatar(
                child: Text("😍"),
              ),
            ),
            Chip(
              label: Text("Shivansh❤️"),
              avatar: CircleAvatar(
                child: Text("👻"),
              ),
            ),
          ],
        )
      ],
    )));
  }
}
