import 'package:flutter/material.dart';

class RESULT extends StatelessWidget {
  double bmiValue;
  RESULT({super.key, required this.bmiValue});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          child: Center(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text("this is your bmi"),
              Text(
                "BMI: ${bmiValue.toString()}",
                style: const TextStyle(fontSize: 25),
              )
            ],
          )),
        ),
      ),
    );
  }
}
