// import 'package:bmi_app/screens/bmi_result.dart';
import 'package:bmi_app/screens/firstpage.dart';
import 'package:bmi_app/screens/loginform.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: const LOGIN(),
    // theme: ThemeData.dark(),
  ));
}
